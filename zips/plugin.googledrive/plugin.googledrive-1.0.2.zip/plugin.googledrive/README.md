# Google Drive KODI Addon
Google Drive for KODI

Play all your media from Google Drive including Videos, Music and Pictures. 
* Unlimited accounts
* Playback your music and videos. Listing of videos with thumbnails.
* Use Google Drive as a source.
* Subtitles can be assigned automatically if a .str file exists with the same name as the video. 
* Export your videos to your library (.strm files). You can export your music too, but kodi won't support it yet. It's a Kodi issue for now.
* Show your photos individually or run a slideshow of them. Listing of pictures with thumbnails.
* Auto-Refreshed slideshow.
* Use of OAuth 2 login. You don't have to write your user/password within the add-on. Use the login process in your browser.
* Extremely fast. Using the Google Drive API

This program is not affiliated with or sponsored by Google.
